"""
Tests for methods shared by DataFrame and Series.
"""
